import mas


class MAS_Client(mas):
    def __init__(self):
        super().__init__()

    def receive_bars(self, symbol, data, is_end=False):
        print(symbol, data, is_end)


def main():
    try:
        mas_client = MAS_Client()
        login_params = {
            "account": "YOUR_ACCOUNT",
            "password": "YOUR_PASSWORD",
            "server": "YOUR_SERVER"
        }
        mas_client.login(login_params)

        params = {
            "symbol": "EURUSD",
            "timeframe": "M1",
            "backtest_toggle": False
            # "from": '2024-01-01',
            # "to": '2024-12-31',
            # "backtest_toggle": True
        }
        mas_client.subscribe_bars(params)
    except Exception as e:
        print(str(e))


if __name__ == "__main__":
    main()
