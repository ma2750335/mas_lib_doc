import mas


class MAS_Client(mas):
    def __init__(self):
        super().__init__()


def main():
    try:
        mas_client = MAS_Client()
        if mas_client.check_connection():
            print("目前已連線至 MT5")
        else:
            print("尚未連線 MT5，請先執行 login")
            
    except Exception as e:
        print(f"初始化失敗:{str(e)}")


if __name__ == "__main__":
    main()