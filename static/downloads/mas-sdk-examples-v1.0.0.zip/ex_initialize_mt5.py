import mas


class MAS_Client(mas):
    def __init__(self):
        super().__init__()


def main():
    try:
        mas_client = MAS_Client()
        if not mas_client.initialize_mt5():
            print("MT5 初始化失敗")
        else:
            print("MT5 已連線")
            
    except Exception as e:
        print(f"初始化失敗:{str(e)}")


if __name__ == "__main__":
    main()
