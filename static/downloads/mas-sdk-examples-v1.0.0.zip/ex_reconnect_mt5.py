import mas


class MAS_Client(mas):
    def __init__(self):
        super().__init__()


def main():
    try:
        mas_client = MAS_Client()
        if not mas_client.check_connection():
            print("MT5 掉線，正在重新連線...")
            success = mas_client.reconnect_mt5()
        if success:
            print("重新連線成功")
        else:
            print("重新連線失敗")
            
    except Exception as e:
        print(f"初始化失敗:{str(e)}")


if __name__ == "__main__":
    main()
